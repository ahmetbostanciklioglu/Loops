import UIKit

let forLoops = 9...15
for index in forLoops {
    print("index is \(index)")
}

let forLoops2 = ["Green"]
for index2 in forLoops2 {
    print("\(index2) ")
}

for i in "ahmet" {
    print("\(i)")
}

for index3 in [2, 3 , 5, 9] {
    print("\(index3)")
}


var index4 = 17
while index4 <= 21 {
    print(index4)
    index4 += 1
}

var repeatLoops = true
repeat {
   print("false")
}while false
